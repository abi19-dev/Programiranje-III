﻿namespace DLWMS.WinForms.Helpers
{
    public class Kljucevi
    {
        public const string NazivResourceFajla = "DLWMS.WinForms.Resource1";
        public const string DobroDosli = "DobroDosli";
        public const string NalogNijeAktivan = "NalogNijeAktivan";
        public const string PodaciNisuValidni = "PodaciNisuValidni";
        public const string Informacija = "Informacija";
        public const string ObaveznaVrijednost = "ObaveznaVrijednost";
        public const string PodaciUspjesnoDodati = "PodaciUspjesnoDodati";
        public const string PodaciUspjesnoModifikovani = "PodaciUspjesnoModifikovani";
        public const string PodatakVecPostoji = "PodatakVecPostoji";


        

    }
}
